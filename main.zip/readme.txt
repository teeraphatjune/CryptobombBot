HOW TO BUILD PROGRAM
- pyinstaller --onefile --windowed main.py

config.txt
- number is equal minutes